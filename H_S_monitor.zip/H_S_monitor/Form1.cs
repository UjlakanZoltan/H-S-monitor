﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using SaveFileDialog = System.Windows.Forms.SaveFileDialog;

namespace H_S_monitor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_back1_Click(object sender, EventArgs e)
        {
            Hide();
            MainWindow main = new MainWindow(true);
            main.ShowDialog();
            Close();
        }

        private void action_btn_get_Click(object sender, EventArgs e)
        {
            string uninstallKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall";
            using (RegistryKey rk = Registry.LocalMachine.OpenSubKey(uninstallKey))
            {
                foreach (string skName in rk.GetSubKeyNames())
                {
                    using (RegistryKey sk = rk.OpenSubKey(skName))
                    {
                        try
                        {

                            var displayName = sk.GetValue("DisplayName");
                            var size = sk.GetValue("EstimatedSize");
                            var version = sk.GetValue("DisplayVersion");
                            var publisher = sk.GetValue("Publisher");

                            ListViewItem item;
                            if (displayName != null)
                            {
                                if (size != null)
                                    item = new ListViewItem(new string[] { displayName.ToString(), size.ToString() + " KB", version.ToString(), publisher.ToString() });
                                else
                                    item = new ListViewItem(new string[] { displayName.ToString(), size.ToString() + " KB", version.ToString(), publisher.ToString() });
                                lstDisplayHardware.Items.Add(item);
                            }
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
                label1.Text += " (" + lstDisplayHardware.Items.Count.ToString() + ")";
            }
        }

        private void btn_export_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog() { Filter= "CSV|*.csv", ValidateNames=true})
            {
                if(sfd.ShowDialog()==DialogResult.OK)
                {
                    using (StreamWriter sw = new StreamWriter(new FileStream(sfd.FileName, FileMode.Create), Encoding.UTF8))
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendLine("DisplayName, EstimatedSize, DisplayVersion, Publisher");
                        foreach (ListViewItem item in lstDisplayHardware.Items)
                        {
                            sb.AppendLine(string.Format("{0},{1},{2},{3}", item.SubItems[0].Text, item.SubItems[1], item.SubItems[2], item.SubItems[3]));
                        }
                        sw.WriteLineAsync(sb.ToString());
                        MessageBox.Show("Successfully exported.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        sw.Close();
                    }
                }
            }
        }
    }
 
}

