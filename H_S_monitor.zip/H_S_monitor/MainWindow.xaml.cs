﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;

namespace H_S_monitor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            
        }

        public MainWindow(bool doNotMakeInvisible)
        {
            InitializeComponent();
        }

        private void btn_software_Click(object sender, RoutedEventArgs e)
        {
            this.Visibility = Visibility.Hidden;
            InitializeComponent();
            Hide();
            Form1 form = new Form1();
            form.ShowDialog();
            Close();
        }

        private void btn_hardware_Click(object sender, RoutedEventArgs e)
        {
            this.Visibility = Visibility.Hidden;
            InitializeComponent();
            Hide();
            WPF1 form = new WPF1();
            form.ShowDialog();
            Close();
        }

        private void tbn_cpuram_Click(object sender, RoutedEventArgs e)
        {
            this.Visibility = Visibility.Hidden;
            InitializeComponent();
            Hide();
            Form3 form = new Form3();
            form.ShowDialog();
            Close();
        }
    }
}
