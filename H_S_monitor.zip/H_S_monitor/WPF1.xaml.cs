﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Management;
using System.IO;

namespace H_S_monitor
{
    /// <summary>
    /// Interaction logic for WPF1.xaml
    /// </summary>
    public partial class WPF1 : Window
    {
        public WPF1()
        {
            InitializeComponent();
        }

        private void btn_software_Click(object sender, RoutedEventArgs e) //Main menü gomb
        {
            Hide();
            MainWindow main = new MainWindow(true);
            main.ShowDialog();
            Close();
        }
        
        private void Button_Click(object sender, RoutedEventArgs e) //GPU info
        {
            ManagementObjectSearcher myVideoObject = new ManagementObjectSearcher("select * from Win32_VideoController");

            foreach (ManagementObject obj in myVideoObject.Get())
            {
                GPU_name_textbox.Text = ("Name  -  " + obj["Name"]);
                GPU_deviceid_textbox.Text = ("DeviceID  -  " + obj["DeviceID"]);
                GPU_adapterram_textbox.Text = ("AdapterRAM  -  " + obj["AdapterRAM"]);
                GPU_monochrome_textbox.Text = ("Monochrome  -  " + obj["Monochrome"]);
                GPU_driverversion_textbox.Text = ("DriverVersion  -  " + obj["DriverVersion"]);
                GPU_videprocessor_textbox.Text = ("VideoProcessor  -  " + obj["VideoProcessor"]);
                GPU_videoarchitecture_textbox.Text = ("VideoArchitecture  -  " + obj["VideoArchitecture"]);
                GPU_videomemorytype_textbox.Text = ("VideoMemoryType  -  " + obj["VideoMemoryType"]);
            }
        }
        
        private void CPU_info_btn_Click(object sender, RoutedEventArgs e) //CPU info
        {
            ManagementObjectSearcher myProcessorObject = new ManagementObjectSearcher("select * from Win32_Processor");

            foreach (ManagementObject obj in myProcessorObject.Get())
            {
                CPU_name_textbox.Text = ("Name  -  " + obj["Name"]);
                CPU_deviceid_textbox.Text = ("DeviceID  -  " + obj["DeviceID"]);
                CPU_manufacturer_textbox.Text = ("Manufacturer  -  " + obj["Manufacturer"]);
                CPU_currentclockspeed_textbox.Text = ("CurrentClockSpeed  -  " + obj["CurrentClockSpeed"]);
                CPU_numberofcores_textbox.Text = ("NumberOfCores  -  " + obj["NumberOfCores"]);
                CPU_numberofenabledcore_textbox.Text = ("NumberOfEnabledCore  -  " + obj["NumberOfEnabledCore"]);
                CPU_numberoflogicalprocessors_textbox.Text = ("NumberOfLogicalProcessors  -  " + obj["NumberOfLogicalProcessors"]);
                CPU_architecture_textbox.Text = ("Architecture  -  " + obj["Architecture"]);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //CPU info törlés
        {
            CPU_name_textbox.Text = ("Name");
            CPU_deviceid_textbox.Text = ("DeviceID");
            CPU_manufacturer_textbox.Text = ("Manufacturer");
            CPU_currentclockspeed_textbox.Text = ("CurrentClockSpeed");
            CPU_numberofcores_textbox.Text = ("NumberOfCores");
            CPU_numberofenabledcore_textbox.Text = ("NumberOfEnabledCore");
            CPU_numberoflogicalprocessors_textbox.Text = ("NumberOfLogicalProcessors");
            CPU_architecture_textbox.Text = ("Architecture");
        }

        private void Clear2_btn_Click(object sender, RoutedEventArgs e) //GPU info törlés
        {
            GPU_name_textbox.Text = ("Name");
            GPU_deviceid_textbox.Text = ("DeviceID");
            GPU_adapterram_textbox.Text = ("AdapterRAM");
            GPU_monochrome_textbox.Text = ("Monochrome");
            GPU_driverversion_textbox.Text = ("DriverVersion");
            GPU_videprocessor_textbox.Text = ("VideoProcessor");
            GPU_videoarchitecture_textbox.Text = ("VideoArchitecture");
            GPU_videomemorytype_textbox.Text = ("VideoMemoryType");
        }

        private void OS_info_btn_Click(object sender, RoutedEventArgs e) //OS info
        {
            ManagementObjectSearcher myOperativeSystemObject = new ManagementObjectSearcher("select * from Win32_OperatingSystem");

            foreach (ManagementObject obj in myOperativeSystemObject.Get())
            {
                OS_Name_textbox.Text = ("Name  -  " + obj["Caption"]);
                OS_windowsdirectory_textbox.Text = ("WindowsDirectory  -  " + obj["WindowsDirectory"]);
                OS_systemdirectory_textbox.Text = ("SystemDirectory  -  " + obj["SystemDirectory"]);
                OS_countrycode_textbox.Text = ("CountryCode  -  " + obj["CountryCode"]);
                OS_currenttimezone_textbox.Text = ("CurrentTimeZone  -  " + obj["CurrentTimeZone"]);
                OS_encryptionlevel_textbox.Text = ("EncryptionLevel  -  " + obj["EncryptionLevel"]);
                OS_ostype_textbox.Text = ("OSType  -  " + obj["OSType"]);
                OS_version_textbox.Text = ("Version  -  " + obj["Version"]);
            }
        }

        private void Clear3_btn_Click(object sender, RoutedEventArgs e)
        {
            OS_Name_textbox.Text = ("Name");
            OS_windowsdirectory_textbox.Text = ("WindowsDirectory");
            OS_systemdirectory_textbox.Text = ("SystemDirectory");
            OS_countrycode_textbox.Text = ("CountryCode");
            OS_currenttimezone_textbox.Text = ("CurrentTimeZone");
            OS_encryptionlevel_textbox.Text = ("EncryptionLevel");
            OS_ostype_textbox.Text = ("OSType");
            OS_version_textbox.Text = ("Version");
        }
    }
}
