﻿namespace H_S_monitor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_back1 = new System.Windows.Forms.Button();
            this.lstDisplayHardware = new System.Windows.Forms.ListView();
            this.DisplayName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.EstimatedSize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DisplayVersion = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Publisher = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.action_btn_get = new System.Windows.Forms.Button();
            this.btn_export = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_back1
            // 
            this.btn_back1.Location = new System.Drawing.Point(692, 12);
            this.btn_back1.Name = "btn_back1";
            this.btn_back1.Size = new System.Drawing.Size(96, 23);
            this.btn_back1.TabIndex = 0;
            this.btn_back1.Text = "Main menu";
            this.btn_back1.UseVisualStyleBackColor = true;
            this.btn_back1.Click += new System.EventHandler(this.btn_back1_Click);
            // 
            // lstDisplayHardware
            // 
            this.lstDisplayHardware.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.DisplayName,
            this.EstimatedSize,
            this.DisplayVersion,
            this.Publisher});
            this.lstDisplayHardware.HideSelection = false;
            this.lstDisplayHardware.Location = new System.Drawing.Point(13, 42);
            this.lstDisplayHardware.Margin = new System.Windows.Forms.Padding(4);
            this.lstDisplayHardware.Name = "lstDisplayHardware";
            this.lstDisplayHardware.Size = new System.Drawing.Size(775, 395);
            this.lstDisplayHardware.TabIndex = 18;
            this.lstDisplayHardware.UseCompatibleStateImageBehavior = false;
            this.lstDisplayHardware.View = System.Windows.Forms.View.Details;
            // 
            // DisplayName
            // 
            this.DisplayName.Text = "DisplayName";
            this.DisplayName.Width = 395;
            // 
            // EstimatedSize
            // 
            this.EstimatedSize.Text = "EstimatedSize";
            this.EstimatedSize.Width = 100;
            // 
            // DisplayVersion
            // 
            this.DisplayVersion.Text = "DisplayVersion";
            this.DisplayVersion.Width = 115;
            // 
            // Publisher
            // 
            this.Publisher.Text = "Publisher";
            this.Publisher.Width = 210;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(184, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 25);
            this.label1.TabIndex = 19;
            this.label1.Text = "RESULT";
            // 
            // action_btn_get
            // 
            this.action_btn_get.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.action_btn_get.ForeColor = System.Drawing.Color.Black;
            this.action_btn_get.Location = new System.Drawing.Point(13, 3);
            this.action_btn_get.Margin = new System.Windows.Forms.Padding(4);
            this.action_btn_get.Name = "action_btn_get";
            this.action_btn_get.Size = new System.Drawing.Size(163, 31);
            this.action_btn_get.TabIndex = 20;
            this.action_btn_get.Text = "GET The List";
            this.action_btn_get.UseVisualStyleBackColor = true;
            this.action_btn_get.Click += new System.EventHandler(this.action_btn_get_Click);
            // 
            // btn_export
            // 
            this.btn_export.Location = new System.Drawing.Point(595, 12);
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(75, 23);
            this.btn_export.TabIndex = 21;
            this.btn_export.Text = "Export";
            this.btn_export.UseVisualStyleBackColor = true;
            this.btn_export.Click += new System.EventHandler(this.btn_export_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_export);
            this.Controls.Add(this.action_btn_get);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstDisplayHardware);
            this.Controls.Add(this.btn_back1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "List of Programs";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_back1;
        private System.Windows.Forms.ListView lstDisplayHardware;
        private System.Windows.Forms.ColumnHeader DisplayName;
        private System.Windows.Forms.ColumnHeader EstimatedSize;
        private System.Windows.Forms.ColumnHeader DisplayVersion;
        private System.Windows.Forms.ColumnHeader Publisher;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button action_btn_get;
        private System.Windows.Forms.Button btn_export;
    }
}